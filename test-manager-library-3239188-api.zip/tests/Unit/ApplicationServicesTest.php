<?php

namespace Tests\Unit;

use App\Application\Ports\BookRepository;
use App\Application\Ports\Clock;
use App\Application\Ports\CoverStorage;
use App\Application\Ports\LoanRepository;
use App\Application\Ports\MemberRepository;
use App\Application\Ports\PasswordHasher;
use App\Application\Ports\ReportReader;
use App\Application\Ports\TokenIssuer;
use App\Application\Ports\UserRepository;
use App\Application\Services\AuthenticationService;
use App\Application\Services\BookService;
use App\Application\Services\CreateLibrarianService;
use App\Application\Services\LoanService;
use App\Application\Services\MemberService;
use App\Application\Services\MostBorrowedReportService;
use App\Domain\Entities\Book;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\ValueObjects\Isbn;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

final class ApplicationServicesTest extends TestCase
{
    public function test_authentication_issues_an_eight_hour_bearer_token(): void
    {
        $users = $this->createMock(UserRepository::class);
        $hasher = $this->createMock(PasswordHasher::class);
        $tokens = $this->createMock(TokenIssuer::class);
        $users->expects(self::once())->method('findByUsername')->with('ana')->willReturn([
            'id' => 'user-1', 'username' => 'ana', 'password_hash' => 'hash', 'role' => 'librarian',
        ]);
        $hasher->expects(self::once())->method('verify')->with('secret', 'hash')->willReturn(true);
        $tokens->expects(self::once())->method('issue')->with('user-1', 'librarian')->willReturn('signed-token');
        $result = (new AuthenticationService($users, $hasher, $tokens))->login(' Ana ', 'secret');
        self::assertSame(['access_token' => 'signed-token', 'token_type' => 'Bearer', 'expires_in' => 28800, 'role' => 'librarian'], $result);
    }

    public function test_librarian_creation_normalizes_username_and_never_returns_password(): void
    {
        $users = $this->createMock(UserRepository::class);
        $hasher = $this->createMock(PasswordHasher::class);
        $hasher->expects(self::once())->method('hash')->with('long-password')->willReturn('argon-hash');
        $users->expects(self::once())->method('create')->with(self::callback(static fn (array $user): bool =>
            $user['username'] === 'ana' && $user['role'] === 'librarian' && $user['password_hash'] === 'argon-hash'
        ))->willReturn([]);
        $result = (new CreateLibrarianService($users, $hasher))->create('Ana ', 'long-password', 'librarian');
        self::assertSame('ana', $result['username']);
        self::assertArrayNotHasKey('password', $result);
        self::assertArrayNotHasKey('password_hash', $result);
    }

    public function test_book_creation_starts_all_copies_available_and_trims_text(): void
    {
        $books = $this->createMock(BookRepository::class);
        $covers = $this->createMock(CoverStorage::class);
        $books->method('categoryExists')->with('category-1')->willReturn(true);
        $books->expects(self::once())->method('create')->with(self::callback(static fn (array $book): bool =>
            $book['title'] === 'Título' && $book['author'] === 'Autora' && $book['total_copies'] === 4
            && $book['available_copies'] === 4 && $book['cover_key'] === null && $book['deleted_at'] === null
        ))->willReturn(['id' => 'book-1']);
        self::assertSame(['id' => 'book-1'], (new BookService($books, $covers))->create([
            'title' => ' Título ', 'author' => ' Autora ', 'isbn' => '9780307474728', 'category_id' => 'category-1', 'total_copies' => 4,
        ]));
    }

    public function test_member_creation_trims_values_and_repository_enforces_unique_document(): void
    {
        $members = $this->createMock(MemberRepository::class);
        $members->expects(self::once())->method('create')->with(self::callback(static fn (array $member): bool =>
            $member['full_name'] === 'María Pérez' && $member['document_number'] === '123456'
        ))->willReturn(['id' => 'member-1']);
        self::assertSame(['id' => 'member-1'], (new MemberService($members))->create(' María Pérez ', ' 123456 '));
    }

    public function test_member_with_an_overdue_item_cannot_start_another_loan(): void
    {
        $books = $this->createMock(BookRepository::class);
        $members = $this->createMock(MemberRepository::class);
        $loans = $this->createMock(LoanRepository::class);
        $clock = $this->createMock(Clock::class);
        $now = new DateTimeImmutable('2026-11-05T14:00:00Z');
        $members->method('find')->with('member-1')->willReturn(['id' => 'member-1']);
        $loans->method('activeItemsForMember')->willReturn([['due_at' => '2026-11-04T14:00:00Z']]);
        $clock->method('now')->willReturn($now);
        $books->expects(self::never())->method('findMany');
        $this->expectException(BusinessRuleViolation::class);
        $this->expectExceptionMessage('El socio tiene libros vencidos');
        (new LoanService($books, $members, $loans, $clock))->create('member-1', ['book-1'], 'user-1');
    }

    public function test_member_with_three_open_items_cannot_borrow_a_fourth(): void
    {
        $books = $this->createMock(BookRepository::class);
        $members = $this->createMock(MemberRepository::class);
        $loans = $this->createMock(LoanRepository::class);
        $clock = $this->createMock(Clock::class);
        $members->method('find')->willReturn(['id' => 'member-1']);
        $loans->method('activeItemsForMember')->willReturn([
            ['due_at' => '2026-11-20T14:00:00Z'], ['due_at' => '2026-11-21T14:00:00Z'], ['due_at' => '2026-11-22T14:00:00Z'],
        ]);
        $clock->method('now')->willReturn(new DateTimeImmutable('2026-11-05T14:00:00Z'));
        $this->expectException(BusinessRuleViolation::class);
        $this->expectExceptionMessage('límite de 3 libros');
        (new LoanService($books, $members, $loans, $clock))->create('member-1', ['book-4'], 'user-1');
    }

    public function test_loan_creation_snapshots_the_book_and_persists_with_optimistic_version(): void
    {
        $bookRepository = $this->createMock(BookRepository::class);
        $members = $this->createMock(MemberRepository::class);
        $loans = $this->createMock(LoanRepository::class);
        $clock = $this->createMock(Clock::class);
        $now = new DateTimeImmutable('2026-11-05T14:00:00Z');
        $book = new Book('book-1', 'Título guardado', 'Autora', new Isbn('9780307474728'), 'category-1', 'Novela', 2, 1, null);
        $members->method('find')->willReturn(['id' => 'member-1']);
        $loans->method('activeItemsForMember')->willReturn([]);
        $clock->method('now')->willReturn($now);
        $bookRepository->expects(self::once())->method('findMany')->with(['book-1'])->willReturn([
            'book-1' => ['book' => $book, 'version' => 'transaction-7'],
        ]);
        $loans->expects(self::once())->method('createAtomically')->with(
            self::callback(static function ($loan) use ($now): bool {
                return $loan->memberId === 'member-1' && $loan->items()[0]['book_title'] === 'Título guardado'
                    && $loan->items()[0]['due_at']->format(DATE_ATOM) === $now->modify('+14 days')->format(DATE_ATOM);
            }),
            ['book-1' => 'transaction-7'],
        )->willReturn(['id' => 'loan-1']);
        self::assertSame(['id' => 'loan-1'], (new LoanService($bookRepository, $members, $loans, $clock))->create('member-1', ['book-1'], 'user-1'));
    }

    public function test_popular_books_report_uses_the_read_port(): void
    {
        $reader = $this->createMock(ReportReader::class);
        $reader->expects(self::once())->method('mostBorrowed')->willReturn([['book_id' => 'book-1', 'times_borrowed' => 4]]);
        $report = (new MostBorrowedReportService($reader))->run('2026-11-01', '2026-11-30');
        self::assertSame('2026-11-01', $report['from']);
        self::assertCount(1, $report['rows']);
    }
}

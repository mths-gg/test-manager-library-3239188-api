<?php

namespace Tests\Unit;

use App\Domain\Entities\Book;
use App\Domain\Entities\Loan;
use App\Domain\Entities\User;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\ValueObjects\DateRange;
use App\Domain\ValueObjects\Isbn;
use App\Domain\ValueObjects\Quantity;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

final class DomainRulesTest extends TestCase
{
    public function test_isbn_requires_thirteen_digits(): void
    {
        self::assertSame('9780307474728', (new Isbn('9780307474728'))->value);
        $this->expectException(BusinessRuleViolation::class);
        new Isbn('123');
    }

    public function test_quantity_must_be_positive(): void
    {
        self::assertSame(1, (new Quantity(1))->value);
        $this->expectException(BusinessRuleViolation::class);
        new Quantity(0);
    }

    public function test_date_range_accepts_equal_bounds_and_rejects_reverse_order(): void
    {
        $day = new DateTimeImmutable('2026-11-05T00:00:00Z');
        new DateRange($day, $day);
        $this->expectException(BusinessRuleViolation::class);
        new DateRange($day->modify('+1 day'), $day);
    }

    public function test_user_normalizes_username_and_rejects_invalid_role(): void
    {
        self::assertSame('ana', (new User('id', 'Ana ', 'librarian'))->username);
        $this->expectException(BusinessRuleViolation::class);
        new User('id', 'Ana', 'owner');
    }

    public function test_loan_snapshots_book_and_sets_due_date_fourteen_days_later(): void
    {
        $now = new DateTimeImmutable('2026-11-05T14:00:00Z');
        $book = new Book('book-1', 'Título original', 'Autor', new Isbn('9780307474728'), 'cat-1', 'Novela', 2, 1, null);
        $loan = new Loan('loan-1', 'member-1', 'user-1', $now);
        $loan->addBook('item-1', $book);
        $item = $loan->items()[0];
        self::assertSame('Título original', $item['book_title']);
        self::assertSame('2026-11-19T14:00:00+00:00', $item['due_at']->format(DATE_ATOM));
    }

    public function test_loan_rejects_unavailable_book(): void
    {
        $book = new Book('book-1', 'Título', 'Autor', new Isbn('9780307474728'), 'cat-1', 'Novela', 1, 0, null);
        $loan = new Loan('loan-1', 'member-1', 'user-1', new DateTimeImmutable('2026-11-05T14:00:00Z'));
        $this->expectException(BusinessRuleViolation::class);
        $loan->addBook('item-1', $book);
    }

    public function test_book_total_change_preserves_the_number_of_loans(): void
    {
        $book = new Book('book-1', 'Título', 'Autor', new Isbn('9780307474728'), 'cat-1', 'Novela', 5, 2, null);
        $expanded = $book->withTotalCopies(7);
        self::assertSame(7, $expanded->totalCopies);
        self::assertSame(4, $expanded->availableCopies);
        $this->expectException(BusinessRuleViolation::class);
        $book->withTotalCopies(2);
    }

    public function test_loan_status_changes_from_open_to_overdue_to_closed(): void
    {
        $start = new DateTimeImmutable('2026-11-05T14:00:00Z');
        $book = new Book('book-1', 'Título', 'Autor', new Isbn('9780307474728'), 'cat-1', 'Novela', 1, 1, null);
        $loan = new Loan('loan-1', 'member-1', 'user-1', $start);
        $loan->addBook('item-1', $book);
        self::assertSame('open', $loan->status($start->modify('+13 days')));
        self::assertSame('overdue', $loan->status($start->modify('+15 days')));
        $loan->returnItem('item-1', $start->modify('+15 days'));
        self::assertSame('closed', $loan->status($start->modify('+16 days')));
    }

    public function test_loan_rejects_a_duplicate_book_and_more_than_three_items(): void
    {
        $loan = new Loan('loan-1', 'member-1', 'user-1', new DateTimeImmutable('2026-11-05T14:00:00Z'));
        $books = [];
        for ($i = 1; $i <= 4; $i++) {
            $books[] = new Book("book-$i", "Título $i", 'Autor', new Isbn('9780307474'.str_pad((string) $i, 3, '0', STR_PAD_LEFT)), 'cat-1', 'Novela', 1, 1, null);
        }
        $loan->addBook('item-1', $books[0]);
        try {
            $loan->addBook('item-duplicate', $books[0]);
            self::fail('Se esperaba rechazar un libro duplicado.');
        } catch (BusinessRuleViolation $exception) {
            self::assertSame('DUPLICATE_BOOK_IN_LOAN', $exception->errorCode);
        }
        $loan->addBook('item-2', $books[1]);
        $loan->addBook('item-3', $books[2]);
        $this->expectException(BusinessRuleViolation::class);
        $loan->addBook('item-4', $books[3]);
    }

    public function test_returning_the_same_line_twice_is_rejected(): void
    {
        $start = new DateTimeImmutable('2026-11-05T14:00:00Z');
        $book = new Book('book-1', 'Título', 'Autor', new Isbn('9780307474728'), 'cat-1', 'Novela', 1, 1, null);
        $loan = new Loan('loan-1', 'member-1', 'user-1', $start);
        $loan->addBook('item-1', $book);
        $loan->returnItem('item-1', $start->modify('+1 day'));
        $this->expectException(BusinessRuleViolation::class);
        $loan->returnItem('item-1', $start->modify('+2 days'));
    }
}

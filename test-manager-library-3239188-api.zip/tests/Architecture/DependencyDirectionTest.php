<?php

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class DependencyDirectionTest extends TestCase
{
    public function test_domain_does_not_depend_on_framework_or_outer_layers(): void
    {
        $root = dirname(__DIR__, 2).'/app/Domain';
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root));
        foreach ($files as $file) {
            if (! $file->isFile() || $file->getExtension() !== 'php') continue;
            $source = file_get_contents($file->getPathname());
            self::assertDoesNotMatchRegularExpression('/use\s+(?:Illuminate|App\\\\(?:Application|Infrastructure|Http))\\\\/', $source, $file->getFilename());
        }
    }

    public function test_application_does_not_depend_on_framework_or_adapters(): void
    {
        $root = dirname(__DIR__, 2).'/app/Application';
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root));
        foreach ($files as $file) {
            if (! $file->isFile() || $file->getExtension() !== 'php') continue;
            $source = file_get_contents($file->getPathname());
            self::assertDoesNotMatchRegularExpression('/use\s+(?:Illuminate|App\\\\(?:Infrastructure|Http))\\\\/', $source, $file->getFilename());
        }
    }
}

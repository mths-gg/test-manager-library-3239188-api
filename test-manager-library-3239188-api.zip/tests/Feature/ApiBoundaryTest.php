<?php

namespace Tests\Feature;

use App\Application\Ports\TokenIssuer;
use Tests\TestCase;

final class ApiBoundaryTest extends TestCase
{
    public function test_health_is_public_and_outside_the_versioned_api(): void
    {
        $this->getJson('/health')->assertOk()->assertExactJson(['status' => 'ok']);
    }

    public function test_catalog_requires_a_token_and_returns_the_common_error_shape(): void
    {
        $this->getJson('/api/v1/books')->assertUnauthorized()
            ->assertJsonPath('code', 'INVALID_CREDENTIALS')
            ->assertJsonStructure(['code', 'message', 'details']);
    }

    public function test_librarian_cannot_open_the_admin_only_report(): void
    {
        $token = $this->app->make(TokenIssuer::class)->issue('user-1', 'librarian');
        $this->withHeader('Authorization', 'Bearer '.$token)
            ->getJson('/api/v1/reports/most-borrowed?from=2026-11-01&to=2026-11-30')
            ->assertForbidden()->assertJsonPath('code', 'FORBIDDEN_ROLE');
    }
}

<?php

return [
    'default' => 'private_covers',
    'disks' => [
        'private_covers' => [
            'driver' => 'local',
            'root' => storage_path('app/private/covers'),
            'throw' => true,
        ],
    ],
];

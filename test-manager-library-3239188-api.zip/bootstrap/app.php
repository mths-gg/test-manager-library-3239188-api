<?php

use App\Http\Middleware\AuthenticateJwt;
use App\Http\Middleware\CorsPolicy;
use App\Http\Middleware\FormatApiErrors;
use App\Http\Middleware\RequireRole;
use App\Domain\Exceptions\BusinessRuleViolation;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Throwable;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        apiPrefix: 'api/v1',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->append(CorsPolicy::class);
        $middleware->alias([
            'jwt' => AuthenticateJwt::class,
            'role' => RequireRole::class,
            'api.errors' => FormatApiErrors::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request): bool => $request->is('api/*') || $request->expectsJson(),
        );
        $exceptions->render(function (BusinessRuleViolation $exception, Request $request) {
            if (! $request->is('api/*')) return null;
            return response()->json(['code' => $exception->errorCode, 'message' => $exception->getMessage(), 'details' => $exception->details], $exception->httpStatus);
        });
        $exceptions->render(function (ValidationException $exception, Request $request) {
            if (! $request->is('api/*')) return null;
            $details = [];
            foreach ($exception->errors() as $field => $messages) foreach ($messages as $message) $details[] = ['field' => $field, 'issue' => $message];
            return response()->json(['code' => 'VALIDATION_ERROR', 'message' => 'Hay campos inválidos.', 'details' => $details], 422);
        });
        $exceptions->render(function (Throwable $exception, Request $request) {
            if (! $request->is('api/*')) return null;
            if ($exception instanceof HttpExceptionInterface) {
                $status = $exception->getStatusCode();
                return response()->json([
                    'code' => $status === 404 ? 'NOT_FOUND' : ($status === 403 ? 'FORBIDDEN_ROLE' : 'HTTP_ERROR'),
                    'message' => $status === 404 ? 'No se encontró el recurso solicitado.' : 'No fue posible completar la solicitud.',
                    'details' => [],
                ], $status);
            }
            Log::error('Error inesperado en la API.', ['exception_class' => $exception::class]);
            return response()->json(['code' => 'INTERNAL_ERROR', 'message' => 'Ocurrió un error interno.', 'details' => []], 500);
        });
    })
    ->create();

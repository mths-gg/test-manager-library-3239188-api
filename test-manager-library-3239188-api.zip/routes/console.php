<?php

use App\Application\Services\AdminBootstrapService;
use Illuminate\Support\Facades\Artisan;

Artisan::command('library:bootstrap-admin', function (AdminBootstrapService $service): void {
    $service->createFromEnvironment();
    $this->info('Administrador inicial disponible.');
})->purpose('Crea el administrador inicial de forma segura desde variables de entorno');

use Illuminate\Support\Facades\Artisan;

Artisan::command('library:bootstrap-admin', function (): void {
    $service = app(App\Application\Services\AdminBootstrapService::class);
    $service->createFromEnvironment();
    $this->info('Administrador inicial verificado.');
})->purpose('Crea el administrador inicial si no existe');

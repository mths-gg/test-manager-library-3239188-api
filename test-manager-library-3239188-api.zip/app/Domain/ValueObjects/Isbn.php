<?php

namespace App\Domain\ValueObjects;

use App\Domain\Exceptions\BusinessRuleViolation;

final readonly class Isbn
{
    public function __construct(public string $value)
    {
        if (! preg_match('/^\d{13}$/', $value)) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El ISBN debe contener exactamente 13 dígitos.', 422, [
                ['field' => 'isbn', 'issue' => 'debe contener 13 dígitos'],
            ]);
        }
    }
}

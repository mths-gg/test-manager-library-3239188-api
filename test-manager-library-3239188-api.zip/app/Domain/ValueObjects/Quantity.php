<?php

namespace App\Domain\ValueObjects;

use App\Domain\Exceptions\BusinessRuleViolation;

final readonly class Quantity
{
    public function __construct(public int $value)
    {
        if ($value < 1) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'La cantidad total debe ser como mínimo 1.', 422, [
                ['field' => 'total_copies', 'issue' => 'debe ser mayor o igual a 1'],
            ]);
        }
    }
}

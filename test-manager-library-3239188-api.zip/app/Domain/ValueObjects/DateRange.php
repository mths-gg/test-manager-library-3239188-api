<?php

namespace App\Domain\ValueObjects;

use App\Domain\Exceptions\BusinessRuleViolation;
use DateTimeImmutable;

final readonly class DateRange
{
    public function __construct(public DateTimeImmutable $from, public DateTimeImmutable $to)
    {
        if ($to < $from) {
            throw new BusinessRuleViolation('INVALID_DATE_RANGE', 'La fecha final debe ser igual o posterior a la inicial.', 422);
        }
    }
}

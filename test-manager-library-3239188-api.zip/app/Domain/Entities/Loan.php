<?php

namespace App\Domain\Entities;

use App\Domain\Exceptions\BusinessRuleViolation;
use DateInterval;
use DateTimeImmutable;

final class Loan
{
    private array $items = [];

    public function __construct(
        public readonly string $id,
        public readonly string $memberId,
        public readonly string $loanedByUserId,
        public readonly DateTimeImmutable $loanedAt,
    ) {
    }

    public function addBook(string $itemId, Book $book): void
    {
        if (count($this->items) >= 3) {
            throw new BusinessRuleViolation('MEMBER_LIMIT_EXCEEDED', 'Un préstamo admite como máximo 3 libros.', 422);
        }
        foreach ($this->items as $item) {
            if ($item['book_id'] === $book->id) {
                throw new BusinessRuleViolation('DUPLICATE_BOOK_IN_LOAN', 'No se puede repetir un libro en el mismo préstamo.', 422);
            }
        }
        if ($book->availableCopies < 1) {
            throw new BusinessRuleViolation('BOOK_NOT_AVAILABLE', 'No quedan ejemplares disponibles de este libro.', 409);
        }

        $this->items[] = $book->snapshot() + [
            'id' => $itemId,
            'due_at' => $this->loanedAt->add(new DateInterval('P14D')),
            'returned_at' => null,
        ];
    }

    public function returnItem(string $itemId, DateTimeImmutable $returnedAt): void
    {
        foreach ($this->items as &$item) {
            if ($item['id'] !== $itemId) continue;
            if ($item['returned_at'] !== null) {
                throw new BusinessRuleViolation('ITEM_ALREADY_RETURNED', 'Este ejemplar ya fue devuelto.', 409);
            }
            $item['returned_at'] = $returnedAt;
            return;
        }
        throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró la línea del préstamo.', 404);
    }

    public function status(DateTimeImmutable $now): string
    {
        return self::calculateStatus($this->items, $now);
    }

    public static function calculateStatus(array $items, DateTimeImmutable $now): string
    {
        $open = array_filter($items, static fn (array $item): bool => ($item['returned_at'] ?? null) === null);
        if ($open === []) return 'closed';
        foreach ($open as $item) {
            $dueAt = $item['due_at'] instanceof DateTimeImmutable ? $item['due_at'] : new DateTimeImmutable($item['due_at']);
            if ($dueAt < $now) return 'overdue';
        }
        return 'open';
    }

    public function items(): array
    {
        return $this->items;
    }
}

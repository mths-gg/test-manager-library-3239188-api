<?php

namespace App\Domain\Entities;

use App\Domain\Exceptions\BusinessRuleViolation;

final readonly class Member
{
    public function __construct(public string $id, public string $fullName, public string $documentNumber)
    {
        if (trim($fullName) === '' || trim($documentNumber) === '') {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El nombre y el documento del socio son obligatorios.', 422);
        }
    }
}

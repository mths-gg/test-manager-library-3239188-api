<?php

namespace App\Domain\Entities;

use App\Domain\Exceptions\BusinessRuleViolation;

final readonly class User
{
    public string $username;

    public function __construct(public string $id, string $username, public string $role)
    {
        $normalized = mb_strtolower(trim($username));
        if ($normalized === '') {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El nombre de usuario es obligatorio.', 422);
        }
        if (! in_array($role, ['admin', 'librarian'], true)) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El rol solicitado no está permitido.', 422);
        }
        $this->username = $normalized;
    }
}

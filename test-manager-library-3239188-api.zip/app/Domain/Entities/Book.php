<?php

namespace App\Domain\Entities;

use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\ValueObjects\Isbn;
use App\Domain\ValueObjects\Quantity;
use DateTimeImmutable;

final class Book
{
    public function __construct(
        public readonly string $id,
        public readonly string $title,
        public readonly string $author,
        public readonly Isbn $isbn,
        public readonly string $categoryId,
        public readonly string $categoryName,
        public readonly int $totalCopies,
        public readonly int $availableCopies,
        public readonly ?string $coverKey,
        public readonly ?string $deletedAt = null,
    ) {
        new Quantity($totalCopies);
        if ($availableCopies < 0 || $availableCopies > $totalCopies) {
            throw new BusinessRuleViolation('BOOK_NOT_AVAILABLE', 'La disponibilidad del libro no es válida.', 409);
        }
        if (trim($title) === '' || trim($author) === '') {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El título y el autor son obligatorios.', 422);
        }
    }

    public function snapshot(): array
    {
        return [
            'book_id' => $this->id,
            'book_title' => $this->title,
            'isbn' => $this->isbn->value,
            'category_name' => $this->categoryName,
        ];
    }

    public function withAvailabilityDelta(int $delta): self
    {
        $available = $this->availableCopies + $delta;
        if ($available < 0 || $available > $this->totalCopies) {
            throw new BusinessRuleViolation('BOOK_NOT_AVAILABLE', 'La cantidad disponible debe permanecer entre cero y el total.', 409);
        }
        return new self($this->id, $this->title, $this->author, $this->isbn, $this->categoryId, $this->categoryName,
            $this->totalCopies, $available, $this->coverKey, $this->deletedAt);
    }

    public function withTotalCopies(int $totalCopies): self
    {
        new Quantity($totalCopies);
        $available = $this->availableCopies + ($totalCopies - $this->totalCopies);
        if ($available < 0) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El nuevo total no puede ser menor que los ejemplares prestados.', 422);
        }
        return new self($this->id, $this->title, $this->author, $this->isbn, $this->categoryId, $this->categoryName,
            $totalCopies, $available, $this->coverKey, $this->deletedAt);
    }

    public function markWithdrawn(DateTimeImmutable $at): self
    {
        return new self($this->id, $this->title, $this->author, $this->isbn, $this->categoryId, $this->categoryName,
            $this->totalCopies, $this->availableCopies, $this->coverKey, $at->format(DATE_ATOM));
    }
}

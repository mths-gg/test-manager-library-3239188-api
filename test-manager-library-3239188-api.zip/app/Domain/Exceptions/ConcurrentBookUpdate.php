<?php

namespace App\Domain\Exceptions;

use RuntimeException;

final class ConcurrentBookUpdate extends RuntimeException
{
}

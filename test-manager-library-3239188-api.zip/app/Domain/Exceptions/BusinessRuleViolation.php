<?php

namespace App\Domain\Exceptions;

use RuntimeException;

final class BusinessRuleViolation extends RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly int $httpStatus = 422,
        public readonly array $details = [],
    ) {
        parent::__construct($message);
    }
}

<?php

namespace App\Providers;

use App\Application\Ports\BookRepository;
use App\Application\Ports\Clock;
use App\Application\Ports\CoverStorage;
use App\Application\Ports\LoanRepository;
use App\Application\Ports\MemberRepository;
use App\Application\Ports\PasswordHasher;
use App\Application\Ports\ReportReader;
use App\Application\Ports\TokenIssuer;
use App\Application\Ports\UserRepository;
use App\Infrastructure\Persistence\PostgresBookRepository;
use App\Infrastructure\Persistence\PostgresLoanRepository;
use App\Infrastructure\Persistence\PostgresMemberRepository;
use App\Infrastructure\Persistence\PostgresReportReader;
use App\Infrastructure\Persistence\PostgresUserRepository;
use App\Infrastructure\Security\ArgonPasswordHasher;
use App\Infrastructure\Security\JwtTokenIssuer;
use App\Infrastructure\Storage\LocalCoverStorage;
use App\Infrastructure\Time\RequestAwareClock;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(Clock::class, RequestAwareClock::class);
        $this->app->bind(PasswordHasher::class, ArgonPasswordHasher::class);
        $this->app->bind(TokenIssuer::class, JwtTokenIssuer::class);
        $this->app->bind(CoverStorage::class, LocalCoverStorage::class);
        $this->app->bind(BookRepository::class, PostgresBookRepository::class);
        $this->app->bind(MemberRepository::class, PostgresMemberRepository::class);
        $this->app->bind(LoanRepository::class, PostgresLoanRepository::class);
        $this->app->bind(UserRepository::class, PostgresUserRepository::class);
        $this->app->bind(ReportReader::class, PostgresReportReader::class);
    }
}

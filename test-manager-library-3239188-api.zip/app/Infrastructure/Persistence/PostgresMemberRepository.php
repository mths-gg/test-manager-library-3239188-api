<?php

namespace App\Infrastructure\Persistence;

use App\Application\Ports\MemberRepository;
use App\Domain\Exceptions\BusinessRuleViolation;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

final class PostgresMemberRepository implements MemberRepository
{
    public function search(string $query, int $page, int $size): array
    {
        $builder = DB::table('library.member as m');
        if ($query !== '') {
            $term = '%'.str_replace(['%', '_'], ['\\%', '\\_'], $query).'%';
            $builder->where(static function ($inner) use ($term): void {
                $inner->where('m.full_name', 'ilike', $term)->orWhere('m.document_number', 'ilike', $term);
            });
        }
        $total = (clone $builder)->count('m.id');
        $items = $builder->orderBy('m.full_name')->forPage($page, $size)
            ->get(['m.id', 'm.full_name', 'm.document_number'])
            ->map(static fn ($row): array => ['id' => $row->id, 'full_name' => $row->full_name, 'document_number' => $row->document_number])
            ->all();
        return compact('items', 'page', 'size', 'total');
    }

    public function find(string $id): ?array
    {
        $row = DB::table('library.member')->where('id', $id)->first();
        if (! $row) {
            return null;
        }
        return [
            'id' => $row->id,
            'full_name' => $row->full_name,
            'document_number' => $row->document_number,
            'active_loans' => DB::table('library.loan_item as li')
                ->join('library.loan as l', 'l.id', '=', 'li.loan_id')
                ->where('l.member_id', $id)->whereNull('li.returned_at')->count(),
        ];
    }

    public function create(array $member): array
    {
        try {
            DB::table('library.member')->insert($member);
        } catch (QueryException $exception) {
            if ((string) $exception->getCode() === '23505') {
                throw new BusinessRuleViolation('DOCUMENT_TAKEN', 'Ya existe un socio con ese documento.', 409);
            }
            throw $exception;
        }
        return $this->find($member['id']) ?? [];
    }
}

<?php

namespace App\Infrastructure\Persistence;

use App\Application\Ports\ReportReader;
use App\Domain\ValueObjects\DateRange;
use Illuminate\Support\Facades\DB;

final class PostgresReportReader implements ReportReader
{
    public function mostBorrowed(DateRange $range): array
    {
        return DB::select(<<<'SQL'
            SELECT li.book_id, li.book_title, li.category_name, COUNT(*)::integer AS times_borrowed
            FROM library.loan AS l
            JOIN library.loan_item AS li ON li.loan_id = l.id
            WHERE l.loaned_at >= ? AND l.loaned_at <= ?
            GROUP BY li.book_id, li.book_title, li.category_name
            ORDER BY times_borrowed DESC, li.book_title ASC
            SQL, [$range->from->format(DATE_ATOM), $range->to->format(DATE_ATOM)]);
    }
}

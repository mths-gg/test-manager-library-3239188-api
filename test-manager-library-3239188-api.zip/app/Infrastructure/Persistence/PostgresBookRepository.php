<?php

namespace App\Infrastructure\Persistence;

use App\Application\Ports\BookRepository;
use App\Domain\Entities\Book;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\ValueObjects\Isbn;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

final class PostgresBookRepository implements BookRepository
{
    public function categories(): array
    {
        return DB::table('library.category')->orderBy('name')->get(['id', 'name'])
            ->map(static fn ($row): array => ['id' => $row->id, 'name' => $row->name])->all();
    }

    public function categoryExists(string $id): bool
    {
        return DB::table('library.category')->where('id', $id)->exists();
    }

    public function find(string $id, bool $activeOnly = true): ?array
    {
        $query = $this->joinedBooks()->where('b.id', $id);
        if ($activeOnly) {
            $query->whereNull('b.deleted_at');
        }
        $row = $query->first();
        return $row ? $this->toApiBook($row) : null;
    }

    public function findMany(array $ids): array
    {
        $rows = $this->joinedBooks()
            ->whereIn('b.id', $ids)
            ->whereNull('b.deleted_at')
            ->get();
        $result = [];
        foreach ($rows as $row) {
            $book = new Book(
                $row->id,
                $row->title,
                $row->author,
                new Isbn(trim($row->isbn)),
                $row->category_id,
                $row->category_name,
                (int) $row->total_copies,
                (int) $row->available_copies,
                $row->cover_key,
                $row->deleted_at,
            );
            $result[$row->id] = ['book' => $book, 'version' => (string) $row->row_version];
        }
        return $result;
    }

    public function search(array $filters, int $page, int $size): array
    {
        $query = $this->joinedBooks()->whereNull('b.deleted_at');
        if (($filters['q'] ?? '') !== '') {
            $term = '%'.str_replace(['%', '_'], ['\\%', '\\_'], $filters['q']).'%';
            $query->where(static function ($builder) use ($term): void {
                $builder->where('b.title', 'ilike', $term)->orWhere('b.author', 'ilike', $term);
            });
        }
        if (($filters['category_id'] ?? '') !== '') {
            $query->where('b.category_id', $filters['category_id']);
        }
        $total = (clone $query)->count('b.id');
        $rows = $query->orderBy('b.title')->forPage($page, $size)->get();

        return [
            'items' => $rows->map(fn ($row): array => $this->toApiBook($row))->all(),
            'page' => $page,
            'size' => $size,
            'total' => $total,
        ];
    }

    public function create(array $book): array
    {
        try {
            DB::table('library.book')->insert($book);
        } catch (QueryException $exception) {
            if ($this->isUniqueViolation($exception)) {
                throw new BusinessRuleViolation('ISBN_TAKEN', 'Ya existe un libro activo con ese ISBN.', 409);
            }
            throw $exception;
        }
        return $this->find($book['id']) ?? [];
    }

    public function update(string $id, array $book): ?array
    {
        return DB::transaction(function () use ($id, $book): ?array {
            $current = $this->joinedBooks()->where('b.id', $id)->whereNull('b.deleted_at')->first();
            if (! $current) {
                return null;
            }
            $available = (int) $current->available_copies + ((int) $book['total_copies'] - (int) $current->total_copies);
            if ($available < 0) {
                throw new BusinessRuleViolation('VALIDATION_ERROR', 'El nuevo total no puede ser menor que los ejemplares prestados.', 422, [
                    ['field' => 'total_copies', 'issue' => 'no puede dejar disponibilidad negativa'],
                ]);
            }
            $affected = DB::update(
                'UPDATE library.book SET title = ?, author = ?, category_id = ?, total_copies = ?, available_copies = ? WHERE id = ? AND xmin::text = ? AND deleted_at IS NULL',
                [$book['title'], $book['author'], $book['category_id'], $book['total_copies'], $available, $id, (string) $current->row_version],
            );
            if ($affected !== 1) {
                throw new BusinessRuleViolation('VALIDATION_ERROR', 'El libro cambió mientras se editaba; vuelve a cargarlo.', 409);
            }
            return $this->find($id);
        });
    }

    public function withdraw(string $id, string $at): string
    {
        return DB::transaction(function () use ($id, $at): string {
            $book = DB::table('library.book')->where('id', $id)->whereNull('deleted_at')->lockForUpdate()->first();
            if (! $book) {
                return 'not_found';
            }
            $hasOpenLoan = DB::table('library.loan_item')->where('book_id', $id)->whereNull('returned_at')->exists();
            if ($hasOpenLoan) {
                return 'has_open_loans';
            }
            DB::table('library.book')->where('id', $id)->whereNull('deleted_at')->update(['deleted_at' => $at]);
            return 'deleted';
        });
    }

    public function putCover(string $id, string $key): ?string
    {
        $current = DB::table('library.book')->where('id', $id)->whereNull('deleted_at')->first(['cover_key']);
        if (! $current) {
            throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el libro solicitado.', 404);
        }
        DB::table('library.book')->where('id', $id)->update(['cover_key' => $key]);
        return $current->cover_key;
    }

    public function removeCover(string $id): ?string
    {
        $current = DB::table('library.book')->where('id', $id)->whereNull('deleted_at')->first(['cover_key']);
        if (! $current) {
            throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el libro solicitado.', 404);
        }
        DB::table('library.book')->where('id', $id)->update(['cover_key' => null]);
        return $current->cover_key;
    }

    public function adjustCopies(string $id, int $newTotal): ?array
    {
        $book = $this->find($id);
        if ($book === null) {
            return null;
        }
        return $this->update($id, [
            'title' => $book['title'],
            'author' => $book['author'],
            'category_id' => $book['category']['id'],
            'total_copies' => $newTotal,
        ]);
    }

    private function joinedBooks()
    {
        return DB::table('library.book as b')
            ->join('library.category as c', 'c.id', '=', 'b.category_id')
            ->select('b.*', 'c.name as category_name', DB::raw('b.xmin::text AS row_version'));
    }

    private function toApiBook(object $row): array
    {
        return [
            'id' => $row->id,
            'title' => $row->title,
            'author' => $row->author,
            'isbn' => trim($row->isbn),
            'category' => ['id' => $row->category_id, 'name' => $row->category_name],
            'total_copies' => (int) $row->total_copies,
            'available_copies' => (int) $row->available_copies,
            'cover_key' => $row->cover_key,
        ];
    }

    private function isUniqueViolation(QueryException $exception): bool
    {
        return (string) $exception->getCode() === '23505';
    }
}

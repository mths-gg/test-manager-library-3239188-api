<?php

namespace App\Infrastructure\Persistence;

use App\Application\Ports\UserRepository;
use App\Domain\Exceptions\BusinessRuleViolation;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

final class PostgresUserRepository implements UserRepository
{
    public function findByUsername(string $username): ?array
    {
        $row = DB::table('library.user')->where('username', $username)->first();
        return $row ? ['id' => $row->id, 'username' => $row->username, 'password_hash' => $row->password_hash, 'role' => $row->role] : null;
    }

    public function findById(string $id): ?array
    {
        $row = DB::table('library.user')->where('id', $id)->first(['id', 'username', 'role']);
        return $row ? ['id' => $row->id, 'username' => $row->username, 'role' => $row->role] : null;
    }

    public function create(array $user): array
    {
        try {
            DB::table('library.user')->insert($user);
        } catch (QueryException $exception) {
            if ((string) $exception->getCode() === '23505') {
                throw new BusinessRuleViolation('USERNAME_TAKEN', 'Ese nombre de usuario ya está registrado.', 409);
            }
            throw $exception;
        }
        return $this->findById($user['id']) ?? [];
    }

    public function exists(): bool
    {
        return DB::table('library.user')->exists();
    }
}

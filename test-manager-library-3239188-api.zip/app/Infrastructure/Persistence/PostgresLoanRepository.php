<?php

namespace App\Infrastructure\Persistence;

use App\Application\Ports\LoanRepository;
use App\Domain\Entities\Loan;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\Exceptions\ConcurrentBookUpdate;
use Illuminate\Support\Facades\DB;

final class PostgresLoanRepository implements LoanRepository
{
    public function activeItemsForMember(string $memberId): array
    {
        return DB::table('library.loan_item as li')->join('library.loan as l', 'l.id', '=', 'li.loan_id')
            ->where('l.member_id', $memberId)->whereNull('li.returned_at')->get(['li.due_at'])
            ->map(static fn ($row): array => ['due_at' => $row->due_at])->all();
    }

    public function createAtomically(Loan $loan, array $versions): array
    {
        return DB::transaction(function () use ($loan, $versions): array {
            // Lockear el socio serializa sus préstamos y mantiene el tope de tres bajo concurrencia.
            $member = DB::table('library.member')->where('id', $loan->memberId)->lockForUpdate()->first(['id']);
            if (! $member) {
                throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el socio solicitado.', 404);
            }
            $active = DB::table('library.loan_item as li')->join('library.loan as l', 'l.id', '=', 'li.loan_id')
                ->where('l.member_id', $loan->memberId)->whereNull('li.returned_at')->get(['li.due_at']);
            foreach ($active as $activeItem) {
                if (new \DateTimeImmutable($activeItem->due_at) < $loan->loanedAt) {
                    throw new BusinessRuleViolation('MEMBER_HAS_OVERDUE', 'El socio tiene libros vencidos y no puede solicitar otro préstamo.', 409);
                }
            }
            if ($active->count() + count($loan->items()) > 3) {
                throw new BusinessRuleViolation('MEMBER_LIMIT_EXCEEDED', 'El socio superaría el límite de 3 libros sin devolver.', 422, [
                    ['field' => 'member_id', 'issue' => 'libros activos actualmente: '.$active->count()],
                ]);
            }
            foreach ($loan->items() as $item) {
                $version = $versions[$item['book_id']] ?? '';
                $affected = DB::update(
                    'UPDATE library.book SET available_copies = available_copies - 1 WHERE id = ? AND xmin::text = ? AND deleted_at IS NULL AND available_copies > 0',
                    [$item['book_id'], $version],
                );
                if ($affected !== 1) {
                    throw new ConcurrentBookUpdate('El inventario del libro cambió.');
                }
            }

            DB::table('library.loan')->insert([
                'id' => $loan->id,
                'member_id' => $loan->memberId,
                'loaned_by_user_id' => $loan->loanedByUserId,
                'loaned_at' => $loan->loanedAt->format('Y-m-d H:i:s.uP'),
            ]);
            foreach ($loan->items() as $item) {
                DB::table('library.loan_item')->insert([
                    'id' => $item['id'], 'loan_id' => $loan->id, 'book_id' => $item['book_id'],
                    'book_title' => $item['book_title'], 'isbn' => $item['isbn'],
                    'category_name' => $item['category_name'], 'due_at' => $item['due_at']->format('Y-m-d H:i:s.uP'),
                    'returned_at' => null,
                ]);
            }
            return $this->find($loan->id) ?? [];
        }, 3);
    }

    public function find(string $id): ?array
    {
        $loan = DB::table('library.loan as l')->join('library.member as m', 'm.id', '=', 'l.member_id')
            ->where('l.id', $id)->first(['l.id', 'l.member_id', 'm.full_name as member_name', 'l.loaned_at']);
        if (! $loan) {
            return null;
        }
        $items = DB::table('library.loan_item')->where('loan_id', $id)->orderBy('due_at')->get()
            ->map(fn ($row): array => $this->item($row))->all();
        return [
            'id' => $loan->id, 'member_id' => $loan->member_id, 'member_name' => $loan->member_name,
            'loaned_at' => $this->iso($loan->loaned_at), 'items' => $items,
        ];
    }

    public function returnItem(string $loanId, string $itemId, string $returnedAt): ?array
    {
        return DB::transaction(function () use ($loanId, $itemId, $returnedAt): ?array {
            $item = DB::table('library.loan_item')->where('loan_id', $loanId)->where('id', $itemId)->lockForUpdate()->first();
            if (! $item) {
                return null;
            }
            if ($item->returned_at !== null) {
                throw new BusinessRuleViolation('ITEM_ALREADY_RETURNED', 'Este ejemplar ya fue devuelto.', 409);
            }
            $updated = DB::table('library.loan_item')->where('id', $itemId)->whereNull('returned_at')->update(['returned_at' => $returnedAt]);
            if ($updated !== 1) {
                throw new BusinessRuleViolation('ITEM_ALREADY_RETURNED', 'Este ejemplar ya fue devuelto.', 409);
            }
            DB::table('library.book')->where('id', $item->book_id)
                ->whereColumn('available_copies', '<', 'total_copies')->increment('available_copies');
            $row = DB::table('library.loan_item')->where('id', $itemId)->first();
            return $this->item($row);
        }, 3);
    }

    public function search(array $filters, int $page, int $size, string $now): array
    {
        $query = DB::table('library.loan as l')->join('library.member as m', 'm.id', '=', 'l.member_id');
        if (! empty($filters['from'])) $query->where('l.loaned_at', '>=', $filters['from'].' 00:00:00+00');
        if (! empty($filters['to'])) $query->where('l.loaned_at', '<=', $filters['to'].' 23:59:59.999999+00');
        if (! empty($filters['member_id'])) $query->where('l.member_id', $filters['member_id']);
        if (($filters['status'] ?? '') === 'overdue') {
            $query->whereExists(fn ($q) => $q->selectRaw('1')->from('library.loan_item as x')->whereColumn('x.loan_id', 'l.id')->whereNull('x.returned_at')->where('x.due_at', '<', $now));
        } elseif (($filters['status'] ?? '') === 'open') {
            $query->whereExists(fn ($q) => $q->selectRaw('1')->from('library.loan_item as x')->whereColumn('x.loan_id', 'l.id')->whereNull('x.returned_at')->where('x.due_at', '>=', $now));
            $query->whereNotExists(fn ($q) => $q->selectRaw('1')->from('library.loan_item as y')->whereColumn('y.loan_id', 'l.id')->whereNull('y.returned_at')->where('y.due_at', '<', $now));
        } elseif (($filters['status'] ?? '') === 'closed') {
            $query->whereNotExists(fn ($q) => $q->selectRaw('1')->from('library.loan_item as x')->whereColumn('x.loan_id', 'l.id')->whereNull('x.returned_at'));
        }
        $total = (clone $query)->count('l.id');
        $ids = $query->orderByDesc('l.loaned_at')->forPage($page, $size)->get(['l.id'])->pluck('id')->all();
        $items = array_values(array_filter(array_map(fn ($id) => $this->find($id), $ids)));
        return compact('items', 'page', 'size', 'total');
    }

    public function overdue(string $now): array
    {
        return DB::table('library.loan_item as li')->join('library.loan as l', 'l.id', '=', 'li.loan_id')
            ->join('library.member as m', 'm.id', '=', 'l.member_id')->whereNull('li.returned_at')->where('li.due_at', '<', $now)
            ->orderBy('li.due_at')->get(['l.id as loan_id', 'li.id as item_id', 'li.book_title', 'm.full_name as member_name', 'li.due_at'])
            ->map(fn ($row): array => [
                'loan_id' => $row->loan_id, 'item_id' => $row->item_id, 'book_title' => $row->book_title,
                'member_name' => $row->member_name, 'due_at' => $this->iso($row->due_at),
                'days_late' => max(1, (int) floor((strtotime($now) - strtotime($row->due_at)) / 86400)),
            ])->all();
    }

    private function item(object $row): array
    {
        return [
            'id' => $row->id, 'book_id' => $row->book_id, 'book_title' => $row->book_title,
            'isbn' => trim($row->isbn), 'category_name' => $row->category_name,
            'due_at' => $this->iso($row->due_at), 'returned_at' => $row->returned_at ? $this->iso($row->returned_at) : null,
        ];
    }

    private function iso(string $value): string
    {
        return (new \DateTimeImmutable($value))->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
    }
}

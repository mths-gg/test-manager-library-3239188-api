<?php

namespace App\Infrastructure\Time;

use App\Application\Ports\Clock;
use DateTimeImmutable;
use DateTimeZone;
use Throwable;

final class RequestAwareClock implements Clock
{
    public function now(): DateTimeImmutable
    {
        $environment = (string) config('app.env');
        $demoEnabled = (bool) config('app.demo_clock_enabled', false);
        $requestedInstant = request()->header('X-Demo-Now');

        if ($demoEnabled && in_array($environment, ['local', 'testing'], true) && is_string($requestedInstant) && $requestedInstant !== '') {
            try {
                return (new DateTimeImmutable($requestedInstant))->setTimezone(new DateTimeZone('UTC'));
            } catch (Throwable) {
                // Ignore malformed demo input and use the real clock.
            }
        }

        return new DateTimeImmutable('now', new DateTimeZone('UTC'));
    }
}

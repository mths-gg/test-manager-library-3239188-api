<?php

namespace App\Infrastructure\Storage;

use App\Application\Ports\CoverStorage;
use App\Application\Support\Uuid;
use Illuminate\Support\Facades\Storage;

final class LocalCoverStorage implements CoverStorage
{
    public function put(string $contents, string $extension): string
    {
        $key = Uuid::v4();
        Storage::disk('private_covers')->put($key.'.bin', $contents);
        return $key;
    }

    public function get(string $key): ?string
    {
        $path = $key.'.bin';
        return Storage::disk('private_covers')->exists($path)
            ? Storage::disk('private_covers')->get($path)
            : null;
    }

    public function delete(string $key): void
    {
        Storage::disk('private_covers')->delete($key.'.bin');
    }
}

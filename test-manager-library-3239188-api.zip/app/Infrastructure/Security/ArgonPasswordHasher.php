<?php

namespace App\Infrastructure\Security;

use App\Application\Ports\PasswordHasher;
use RuntimeException;

final class ArgonPasswordHasher implements PasswordHasher
{
    public function hash(string $password): string
    {
        $hash = password_hash($password, PASSWORD_ARGON2ID);
        if ($hash === false) {
            throw new RuntimeException('No fue posible proteger la contraseña.');
        }

        return $hash;
    }

    public function verify(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }
}

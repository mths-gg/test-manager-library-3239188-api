<?php

namespace App\Infrastructure\Security;

use App\Application\Ports\TokenIssuer;
use App\Domain\Exceptions\BusinessRuleViolation;
use DateTimeImmutable;
use DateTimeZone;

final class JwtTokenIssuer implements TokenIssuer
{
    private const TTL_SECONDS = 28800;

    public function issue(string $userId, string $role): string
    {
        $now = time();
        $header = ['alg' => 'HS256', 'typ' => 'JWT'];
        $payload = ['sub' => $userId, 'role' => $role, 'iat' => $now, 'exp' => $now + self::TTL_SECONDS];
        $unsigned = $this->encode($header).'.'.$this->encode($payload);
        $signature = hash_hmac('sha256', $unsigned, $this->secret(), true);

        return $unsigned.'.'.$this->base64UrlEncode($signature);
    }

    public function verify(string $token): array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            throw $this->invalidToken();
        }

        [$encodedHeader, $encodedPayload, $encodedSignature] = $parts;
        $header = json_decode($this->base64UrlDecode($encodedHeader), true);
        $claims = json_decode($this->base64UrlDecode($encodedPayload), true);
        $signature = $this->base64UrlDecode($encodedSignature);

        if (! is_array($header) || ($header['alg'] ?? null) !== 'HS256' || ! is_array($claims)) {
            throw $this->invalidToken();
        }

        $expected = hash_hmac('sha256', $encodedHeader.'.'.$encodedPayload, $this->secret(), true);
        if (! hash_equals($expected, $signature) || ! isset($claims['sub'], $claims['role'], $claims['exp']) || (int) $claims['exp'] <= time()) {
            throw $this->invalidToken();
        }

        return $claims;
    }

    private function secret(): string
    {
        $secret = (string) env('JWT_SECRET', '');
        if (strlen($secret) < 32 || str_contains($secret, 'replace-with')) {
            throw new BusinessRuleViolation('SERVER_CONFIGURATION_ERROR', 'La clave de autenticación no está configurada.', 500);
        }

        return $secret;
    }

    private function encode(array $value): string
    {
        return $this->base64UrlEncode((string) json_encode($value, JSON_UNESCAPED_SLASHES));
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): string
    {
        $decoded = base64_decode(strtr($value, '-_', '+/').str_repeat('=', (4 - strlen($value) % 4) % 4), true);
        return $decoded === false ? '' : $decoded;
    }

    private function invalidToken(): BusinessRuleViolation
    {
        return new BusinessRuleViolation('INVALID_CREDENTIALS', 'El token no es válido o ya venció.', 401);
    }
}

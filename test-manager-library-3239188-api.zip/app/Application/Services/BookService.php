<?php

namespace App\Application\Services;

use App\Application\Ports\BookRepository;
use App\Application\Ports\CoverStorage;
use App\Application\Support\Uuid;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\ValueObjects\Isbn;
use App\Domain\ValueObjects\Quantity;

final class BookService
{
    public function __construct(private readonly BookRepository $books, private readonly CoverStorage $covers)
    {
    }

    public function categories(): array
    {
        return $this->books->categories();
    }

    public function search(array $filters, int $page, int $size): array
    {
        return $this->books->search($filters, $page, $size);
    }

    public function find(string $id): array
    {
        return $this->books->find($id) ?? throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el libro solicitado.', 404);
    }

    public function create(array $input): array
    {
        $isbn = new Isbn((string) $input['isbn']);
        $quantity = new Quantity((int) $input['total_copies']);
        $title = trim((string) $input['title']);
        $author = trim((string) $input['author']);
        if ($title === '' || $author === '') {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El título y el autor no pueden quedar vacíos.', 422);
        }
        if (! $this->books->categoryExists((string) $input['category_id'])) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'La categoría seleccionada no existe.', 422);
        }

        return $this->books->create([
            'id' => Uuid::v4(),
            'title' => $title,
            'author' => $author,
            'isbn' => $isbn->value,
            'category_id' => $input['category_id'],
            'total_copies' => $quantity->value,
            'available_copies' => $quantity->value,
            'cover_key' => null,
            'deleted_at' => null,
        ]);
    }

    public function update(string $id, array $input): array
    {
        $title = trim((string) $input['title']);
        $author = trim((string) $input['author']);
        if ($title === '' || $author === '') {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'El título y el autor no pueden quedar vacíos.', 422);
        }
        if (! $this->books->categoryExists((string) $input['category_id'])) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'La categoría seleccionada no existe.', 422);
        }
        new Quantity((int) $input['total_copies']);

        return $this->books->update($id, [
            'title' => $title,
            'author' => $author,
            'category_id' => $input['category_id'],
            'total_copies' => (int) $input['total_copies'],
        ]) ?? throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el libro solicitado.', 404);
    }

    public function withdraw(string $id, string $at): void
    {
        $result = $this->books->withdraw($id, $at);
        if ($result === 'not_found') {
            throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el libro solicitado.', 404);
        }
        if ($result === 'has_open_loans') {
            throw new BusinessRuleViolation('BOOK_HAS_OPEN_LOANS', 'El libro tiene préstamos abiertos y no se puede dar de baja.', 409);
        }
    }

    public function setCover(string $id, string $contents, string $extension): array
    {
        $this->find($id);
        $newKey = $this->covers->put($contents, $extension);
        try {
            $oldKey = $this->books->putCover($id, $newKey);
        } catch (\Throwable $exception) {
            $this->covers->delete($newKey);
            throw $exception;
        }
        if ($oldKey !== null) {
            $this->covers->delete($oldKey);
        }

        return $this->find($id);
    }

    public function removeCover(string $id): void
    {
        $this->find($id);
        $oldKey = $this->books->removeCover($id);
        if ($oldKey === null && $this->books->find($id) === null) {
            throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el libro solicitado.', 404);
        }
        if ($oldKey !== null) {
            $this->covers->delete($oldKey);
        }
    }
}

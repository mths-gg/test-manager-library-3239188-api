<?php

namespace App\Application\Services;

use App\Application\Ports\MemberRepository;
use App\Application\Support\Uuid;
use App\Domain\Entities\Member;
use App\Domain\Exceptions\BusinessRuleViolation;

final class MemberService
{
    public function __construct(private readonly MemberRepository $members)
    {
    }

    public function search(string $query, int $page, int $size): array
    {
        return $this->members->search($query, $page, $size);
    }

    public function find(string $id): array
    {
        return $this->members->find($id) ?? throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el socio solicitado.', 404);
    }

    public function create(string $fullName, string $documentNumber): array
    {
        $member = new Member(Uuid::v4(), trim($fullName), trim($documentNumber));
        return $this->members->create([
            'id' => $member->id,
            'full_name' => $member->fullName,
            'document_number' => $member->documentNumber,
        ]);
    }
}

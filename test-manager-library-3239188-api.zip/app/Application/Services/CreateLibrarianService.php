<?php

namespace App\Application\Services;

use App\Application\Ports\PasswordHasher;
use App\Application\Ports\UserRepository;
use App\Application\Support\Uuid;
use App\Domain\Entities\User;
use App\Domain\Exceptions\BusinessRuleViolation;

final class CreateLibrarianService
{
    public function __construct(private readonly UserRepository $users, private readonly PasswordHasher $hasher)
    {
    }

    public function create(string $username, string $password, string $role): array
    {
        if ($role !== 'librarian') {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'La API solo permite crear usuarios con rol librarian.', 422, [
                ['field' => 'role', 'issue' => 'solo se permite librarian'],
            ]);
        }
        if (strlen($password) < 8) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'La contraseña debe tener al menos 8 caracteres.', 422);
        }

        $user = new User(Uuid::v4(), $username, 'librarian');
        $this->users->create([
            'id' => $user->id,
            'username' => $user->username,
            'password_hash' => $this->hasher->hash($password),
            'role' => $user->role,
        ]);

        return ['id' => $user->id, 'username' => $user->username, 'role' => $user->role];
    }
}

<?php

namespace App\Application\Services;

use App\Application\Ports\ReportReader;
use App\Domain\ValueObjects\DateRange;
use DateTimeImmutable;
use DateTimeZone;

final class MostBorrowedReportService
{
    public function __construct(private readonly ReportReader $reports)
    {
    }

    public function run(string $from, string $to): array
    {
        $utc = new DateTimeZone('UTC');
        $start = new DateTimeImmutable($from.' 00:00:00', $utc);
        $end = new DateTimeImmutable($to.' 23:59:59.999999', $utc);
        $range = new DateRange($start, $end);

        return [
            'from' => $from,
            'to' => $to,
            'rows' => $this->reports->mostBorrowed($range),
        ];
    }
}

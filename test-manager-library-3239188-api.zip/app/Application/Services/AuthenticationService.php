<?php

namespace App\Application\Services;

use App\Application\Ports\PasswordHasher;
use App\Application\Ports\TokenIssuer;
use App\Application\Ports\UserRepository;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\Entities\User;

final class AuthenticationService
{
    public function __construct(
        private readonly UserRepository $users,
        private readonly PasswordHasher $hasher,
        private readonly TokenIssuer $tokens,
    ) {
    }

    public function login(string $username, string $password): array
    {
        $user = $this->users->findByUsername(mb_strtolower(trim($username)));
        if ($user === null || ! $this->hasher->verify($password, $user['password_hash'])) {
            throw new BusinessRuleViolation('INVALID_CREDENTIALS', 'Usuario o contraseña incorrectos.', 401);
        }

        $operator = new User($user['id'], $user['username'], $user['role']);

        return [
            'access_token' => $this->tokens->issue($operator->id, $operator->role),
            'token_type' => 'Bearer',
            'expires_in' => 28800,
            'role' => $operator->role,
        ];
    }
}

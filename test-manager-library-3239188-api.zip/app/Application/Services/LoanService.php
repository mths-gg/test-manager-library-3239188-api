<?php

namespace App\Application\Services;

use App\Application\Ports\BookRepository;
use App\Application\Ports\Clock;
use App\Application\Ports\LoanRepository;
use App\Application\Ports\MemberRepository;
use App\Application\Support\Uuid;
use App\Domain\Entities\Loan;
use App\Domain\Exceptions\BusinessRuleViolation;
use App\Domain\Exceptions\ConcurrentBookUpdate;
use DateTimeImmutable;

final class LoanService
{
    public function __construct(
        private readonly BookRepository $books,
        private readonly MemberRepository $members,
        private readonly LoanRepository $loans,
        private readonly Clock $clock,
    ) {
    }

    public function create(string $memberId, array $bookIds, string $operatorId): array
    {
        if (count($bookIds) < 1 || count($bookIds) > 3) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'Un préstamo debe incluir de 1 a 3 libros.', 422);
        }
        if (count(array_unique($bookIds)) !== count($bookIds)) {
            throw new BusinessRuleViolation('DUPLICATE_BOOK_IN_LOAN', 'No se puede repetir un libro en el mismo préstamo.', 422);
        }
        if ($this->members->find($memberId) === null) {
            throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el socio solicitado.', 404);
        }

        $activeItems = $this->loans->activeItemsForMember($memberId);
        $now = $this->clock->now();
        foreach ($activeItems as $item) {
            if (new DateTimeImmutable($item['due_at']) < $now) {
                throw new BusinessRuleViolation('MEMBER_HAS_OVERDUE', 'El socio tiene libros vencidos y no puede solicitar otro préstamo.', 409);
            }
        }
        if (count($activeItems) + count($bookIds) > 3) {
            throw new BusinessRuleViolation('MEMBER_LIMIT_EXCEEDED', 'El socio superaría el límite de 3 libros sin devolver.', 422, [
                ['field' => 'member_id', 'issue' => 'libros activos actualmente: '.count($activeItems)],
            ]);
        }

        for ($attempt = 0; $attempt < 2; $attempt++) {
            $rows = $this->books->findMany($bookIds);
            if (count($rows) !== count($bookIds)) {
                throw new BusinessRuleViolation('NOT_FOUND', 'Uno o más libros no existen o fueron dados de baja.', 404);
            }
            $loan = new Loan(Uuid::v4(), $memberId, $operatorId, $now);
            $versions = [];
            foreach ($bookIds as $bookId) {
                $row = $rows[$bookId];
                $loan->addBook(Uuid::v4(), $row['book']);
                $versions[$bookId] = $row['version'];
            }
            try {
                return $this->loans->createAtomically($loan, $versions);
            } catch (ConcurrentBookUpdate) {
                if ($attempt === 1) {
                    throw new BusinessRuleViolation('BOOK_NOT_AVAILABLE', 'El inventario cambió durante el préstamo. Intenta de nuevo.', 409);
                }
            }
        }

        throw new BusinessRuleViolation('BOOK_NOT_AVAILABLE', 'No fue posible registrar el préstamo.', 409);
    }

    public function find(string $id): array
    {
        $loan = $this->loans->find($id) ?? throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró el préstamo solicitado.', 404);
        $loan['status'] = Loan::calculateStatus($loan['items'], $this->clock->now());
        return $loan;
    }

    public function search(array $filters, int $page, int $size): array
    {
        $result = $this->loans->search($filters, $page, $size, $this->clock->now()->format(DATE_ATOM));
        foreach ($result['items'] as &$loan) {
            $loan['status'] = Loan::calculateStatus($loan['items'], $this->clock->now());
        }
        return $result;
    }

    public function returnItem(string $loanId, string $itemId): array
    {
        return $this->loans->returnItem($loanId, $itemId, $this->clock->now()->format(DATE_ATOM))
            ?? throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró la línea del préstamo.', 404);
    }

    public function overdue(): array
    {
        return $this->loans->overdue($this->clock->now()->format(DATE_ATOM));
    }

}

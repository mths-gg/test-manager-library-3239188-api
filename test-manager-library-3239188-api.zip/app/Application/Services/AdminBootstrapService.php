<?php

namespace App\Application\Services;

use App\Application\Ports\PasswordHasher;
use App\Application\Ports\UserRepository;
use App\Application\Support\Uuid;
use App\Domain\Entities\User;
use RuntimeException;

final class AdminBootstrapService
{
    public function __construct(private readonly UserRepository $users, private readonly PasswordHasher $hasher)
    {
    }

    public function createFromEnvironment(): void
    {
        $username = (string) env('ADMIN_USERNAME', '');
        $password = (string) env('ADMIN_PASSWORD', '');
        if ($username === '' || strlen($password) < 12 || str_contains($password, 'change-this')) {
            throw new RuntimeException('Configura ADMIN_USERNAME y una ADMIN_PASSWORD segura antes de crear el administrador.');
        }

        if ($this->users->exists()) {
            $existing = $this->users->findByUsername(mb_strtolower(trim($username)));
            if ($existing !== null && $existing['role'] === 'admin') {
                return;
            }
            throw new RuntimeException('Ya existen usuarios; el administrador inicial no se reemplaza automáticamente.');
        }

        $admin = new User(Uuid::v4(), $username, 'admin');
        $this->users->create([
            'id' => $admin->id,
            'username' => $admin->username,
            'password_hash' => $this->hasher->hash($password),
            'role' => $admin->role,
        ]);
    }
}

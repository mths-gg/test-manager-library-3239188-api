<?php

namespace App\Application\Ports;

use App\Domain\ValueObjects\DateRange;

interface ReportReader
{
    public function mostBorrowed(DateRange $range): array;
}

<?php

namespace App\Application\Ports;

interface UserRepository
{
    public function findByUsername(string $username): ?array;

    public function findById(string $id): ?array;

    public function create(array $user): array;

    public function exists(): bool;
}

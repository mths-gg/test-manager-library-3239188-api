<?php

namespace App\Application\Ports;

use App\Domain\Entities\Book;

interface BookRepository
{
    public function categories(): array;

    public function categoryExists(string $id): bool;

    public function find(string $id, bool $activeOnly = true): ?array;

    public function findMany(array $ids): array;

    public function search(array $filters, int $page, int $size): array;

    public function create(array $book): array;

    public function update(string $id, array $book): ?array;

    public function withdraw(string $id, string $at): string;

    public function putCover(string $id, string $key): ?string;

    public function removeCover(string $id): ?string;

    public function adjustCopies(string $id, int $newTotal): ?array;
}

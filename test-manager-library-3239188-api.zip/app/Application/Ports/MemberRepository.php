<?php

namespace App\Application\Ports;

interface MemberRepository
{
    public function search(string $query, int $page, int $size): array;

    public function find(string $id): ?array;

    public function create(array $member): array;
}

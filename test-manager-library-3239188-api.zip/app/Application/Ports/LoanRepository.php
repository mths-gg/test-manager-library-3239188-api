<?php

namespace App\Application\Ports;

use App\Domain\Entities\Loan;

interface LoanRepository
{
    public function activeItemsForMember(string $memberId): array;

    public function createAtomically(Loan $loan, array $versions): array;

    public function find(string $id): ?array;

    public function returnItem(string $loanId, string $itemId, string $returnedAt): ?array;

    public function search(array $filters, int $page, int $size, string $now): array;

    public function overdue(string $now): array;
}

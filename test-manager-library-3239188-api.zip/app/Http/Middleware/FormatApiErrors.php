<?php

namespace App\Http\Middleware;

use App\Domain\Exceptions\BusinessRuleViolation;
use Closure;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Throwable;

final class FormatApiErrors
{
    public function handle(Request $request, Closure $next): mixed
    {
        try {
            return $next($request);
        } catch (BusinessRuleViolation $exception) {
            return response()->json([
                'code' => $exception->errorCode,
                'message' => $exception->getMessage(),
                'details' => $exception->details,
            ], $exception->httpStatus);
        } catch (ValidationException $exception) {
            $details = [];
            foreach ($exception->errors() as $field => $messages) {
                foreach ($messages as $message) $details[] = ['field' => $field, 'issue' => $message];
            }
            return response()->json(['code' => 'VALIDATION_ERROR', 'message' => 'Hay campos inválidos.', 'details' => $details], 422);
        } catch (HttpExceptionInterface $exception) {
            $status = $exception->getStatusCode();
            return response()->json([
                'code' => $status === 404 ? 'NOT_FOUND' : ($status === 403 ? 'FORBIDDEN_ROLE' : 'HTTP_ERROR'),
                'message' => $status === 404 ? 'No se encontró el recurso solicitado.' : 'No fue posible completar la solicitud.',
                'details' => [],
            ], $status);
        } catch (Throwable $exception) {
            Log::error('Error inesperado en la API.', ['exception_class' => $exception::class]);
            return response()->json(['code' => 'INTERNAL_ERROR', 'message' => 'Ocurrió un error interno.', 'details' => []], 500);
        }
    }
}

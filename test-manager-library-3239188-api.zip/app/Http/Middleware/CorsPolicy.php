<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

final class CorsPolicy
{
    public function handle(Request $request, Closure $next): mixed
    {
        $origin = (string) $request->headers->get('Origin', '');
        $allowed = (string) env('CORS_ORIGIN', 'http://localhost:5173');
        if ($request->isMethod('OPTIONS')) {
            $response = response('', 204);
        } else {
            $response = $next($request);
        }
        if ($origin !== '' && hash_equals($allowed, $origin)) {
            $response->headers->set('Access-Control-Allow-Origin', $origin);
            $response->headers->set('Vary', 'Origin');
            $response->headers->set('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Demo-Now');
            $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        }
        return $response;
    }
}

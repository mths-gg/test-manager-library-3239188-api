<?php

namespace App\Http\Middleware;

use App\Domain\Exceptions\BusinessRuleViolation;
use Closure;
use Illuminate\Http\Request;

final class RequireRole
{
    public function handle(Request $request, Closure $next, string ...$roles): mixed
    {
        if (! in_array($request->attributes->get('auth_role'), $roles, true)) {
            throw new BusinessRuleViolation('FORBIDDEN_ROLE', 'No tienes permiso para realizar esta operación.', 403);
        }
        return $next($request);
    }
}

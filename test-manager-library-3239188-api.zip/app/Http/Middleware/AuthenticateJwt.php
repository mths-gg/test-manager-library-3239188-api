<?php

namespace App\Http\Middleware;

use App\Application\Ports\TokenIssuer;
use App\Domain\Exceptions\BusinessRuleViolation;
use Closure;
use Illuminate\Http\Request;

final class AuthenticateJwt
{
    public function __construct(private readonly TokenIssuer $tokens) {}

    public function handle(Request $request, Closure $next): mixed
    {
        $header = (string) $request->header('Authorization', '');
        if (! preg_match('/^Bearer\s+(.+)$/i', $header, $matches)) {
            throw new BusinessRuleViolation('INVALID_CREDENTIALS', 'Se requiere un token Bearer válido.', 401);
        }
        $claims = $this->tokens->verify($matches[1]);
        $request->attributes->set('auth_user_id', $claims['sub']);
        $request->attributes->set('auth_role', $claims['role']);
        return $next($request);
    }
}

<?php

namespace App\Http\Controllers;

use App\Application\Services\LoanService;
use App\Domain\Exceptions\BusinessRuleViolation;
use Illuminate\Http\Request;

final class LoanController extends Controller
{
    public function index(Request $request, LoanService $loans)
    {
        $data = $request->validate([
            'from' => ['sometimes', 'date_format:Y-m-d'], 'to' => ['sometimes', 'date_format:Y-m-d'],
            'status' => ['sometimes', 'in:open,overdue,closed'], 'member_id' => ['sometimes', 'uuid'],
            'page' => ['sometimes', 'integer', 'min:1'], 'size' => ['sometimes', 'integer', 'min:1', 'max:50'],
        ]);
        if (isset($data['from'], $data['to']) && $data['from'] > $data['to']) {
            throw new BusinessRuleViolation('INVALID_DATE_RANGE', 'La fecha inicial no puede ser posterior a la fecha final.', 422);
        }
        return response()->json($loans->search($data, (int) ($data['page'] ?? 1), (int) ($data['size'] ?? 20)));
    }

    public function show(string $id, LoanService $loans) { return response()->json($loans->find($id)); }
    public function overdue(LoanService $loans) { return response()->json(['items' => $loans->overdue()]); }

    public function store(Request $request, LoanService $loans)
    {
        $data = $request->validate([
            'member_id' => ['required', 'uuid'], 'items' => ['required', 'array', 'min:1', 'max:3'],
            'items.*.book_id' => ['required', 'uuid'],
        ]);
        return response()->json($loans->create($data['member_id'], array_column($data['items'], 'book_id'), (string) $request->attributes->get('auth_user_id')), 201);
    }

    public function returnItem(string $loanId, string $itemId, LoanService $loans)
    {
        return response()->json($loans->returnItem($loanId, $itemId));
    }
}

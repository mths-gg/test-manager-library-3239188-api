<?php

namespace App\Http\Controllers;

use App\Application\Services\AuthenticationService;
use Illuminate\Http\Request;

final class AuthController extends Controller
{
    public function login(Request $request, AuthenticationService $auth)
    {
        $data = $request->validate(['username' => ['required', 'string', 'max:120'], 'password' => ['required', 'string', 'max:200']]);
        return response()->json($auth->login($data['username'], $data['password']));
    }
}

<?php

namespace App\Http\Controllers;

use App\Application\Services\MostBorrowedReportService;
use App\Domain\Exceptions\BusinessRuleViolation;
use Illuminate\Http\Request;

final class ReportController extends Controller
{
    public function mostBorrowed(Request $request, MostBorrowedReportService $reports)
    {
        $data = $request->validate(['from' => ['required', 'date_format:Y-m-d'], 'to' => ['required', 'date_format:Y-m-d']]);
        if ($data['from'] > $data['to']) {
            throw new BusinessRuleViolation('INVALID_DATE_RANGE', 'La fecha inicial no puede ser posterior a la fecha final.', 422);
        }
        return response()->json($reports->run($data['from'], $data['to']));
    }
}

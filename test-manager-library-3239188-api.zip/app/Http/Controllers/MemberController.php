<?php

namespace App\Http\Controllers;

use App\Application\Services\MemberService;
use Illuminate\Http\Request;

final class MemberController extends Controller
{
    public function index(Request $request, MemberService $members)
    {
        $data = $request->validate([
            'q' => ['sometimes', 'string', 'max:150'], 'page' => ['sometimes', 'integer', 'min:1'],
            'size' => ['sometimes', 'integer', 'min:1', 'max:50'],
        ]);
        return response()->json($members->search((string) ($data['q'] ?? ''), (int) ($data['page'] ?? 1), (int) ($data['size'] ?? 20)));
    }

    public function show(string $id, MemberService $members) { return response()->json($members->find($id)); }

    public function store(Request $request, MemberService $members)
    {
        $data = $request->validate([
            'full_name' => ['required', 'string', 'min:2', 'max:200'],
            'document_number' => ['required', 'string', 'min:4', 'max:30'],
        ]);
        return response()->json($members->create($data['full_name'], $data['document_number']), 201);
    }
}

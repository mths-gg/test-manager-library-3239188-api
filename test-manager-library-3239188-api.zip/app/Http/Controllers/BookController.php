<?php

namespace App\Http\Controllers;

use App\Application\Ports\CoverStorage;
use App\Application\Services\BookService;
use App\Domain\Exceptions\BusinessRuleViolation;
use Illuminate\Http\Request;

final class BookController extends Controller
{
    public function index(Request $request, BookService $books)
    {
        $data = $request->validate([
            'q' => ['sometimes', 'string', 'max:150'], 'category_id' => ['sometimes', 'uuid'],
            'page' => ['sometimes', 'integer', 'min:1'], 'size' => ['sometimes', 'integer', 'min:1', 'max:50'],
        ]);
        return response()->json($books->search($data, (int) ($data['page'] ?? 1), (int) ($data['size'] ?? 20)));
    }

    public function categories(BookService $books) { return response()->json(['items' => $books->categories()]); }
    public function show(string $id, BookService $books) { return response()->json($books->find($id)); }

    public function store(Request $request, BookService $books)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:250'], 'author' => ['required', 'string', 'max:200'],
            'isbn' => ['required', 'string', 'size:13', 'regex:/^[0-9]{13}$/'], 'category_id' => ['required', 'uuid'],
            'total_copies' => ['required', 'integer', 'min:1'],
        ]);
        return response()->json($books->create($data), 201);
    }

    public function update(Request $request, string $id, BookService $books)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:250'], 'author' => ['required', 'string', 'max:200'],
            'category_id' => ['required', 'uuid'], 'total_copies' => ['required', 'integer', 'min:1'],
        ]);
        return response()->json($books->update($id, $data));
    }

    public function destroy(string $id, BookService $books, \App\Application\Ports\Clock $clock)
    {
        $books->withdraw($id, $clock->now()->format(DATE_ATOM));
        return response()->noContent();
    }

    public function uploadCover(Request $request, string $id, BookService $books)
    {
        $data = $request->validate(['file' => ['required', 'file', 'max:2048', 'mimes:jpg,jpeg,png']]);
        $file = $data['file'];
        $mime = $file->getMimeType();
        if (! in_array($mime, ['image/jpeg', 'image/png'], true)) {
            throw new BusinessRuleViolation('VALIDATION_ERROR', 'La portada debe ser una imagen JPEG o PNG válida.', 422);
        }
        return response()->json($books->setCover($id, file_get_contents($file->getRealPath()), $mime === 'image/png' ? 'png' : 'jpg'));
    }

    public function deleteCover(string $id, BookService $books)
    {
        $books->removeCover($id);
        return response()->noContent();
    }

    public function cover(string $id, BookService $books, CoverStorage $storage)
    {
        $book = $books->find($id);
        if (! $book['cover_key']) throw new BusinessRuleViolation('NOT_FOUND', 'El libro no tiene portada.', 404);
        $contents = $storage->get($book['cover_key']);
        if ($contents === null) throw new BusinessRuleViolation('NOT_FOUND', 'No se encontró la portada.', 404);
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->buffer($contents) ?: 'application/octet-stream';
        return response($contents, 200, ['Content-Type' => $mime, 'Cache-Control' => 'private, max-age=3600', 'X-Content-Type-Options' => 'nosniff']);
    }
}

<?php

namespace App\Http\Controllers;

use App\Application\Services\CreateLibrarianService;
use Illuminate\Http\Request;

final class UserController extends Controller
{
    public function store(Request $request, CreateLibrarianService $service)
    {
        $data = $request->validate([
            'username' => ['required', 'string', 'min:3', 'max:120'],
            'password' => ['required', 'string', 'min:8', 'max:200'],
            'role' => ['required', 'in:librarian'],
        ]);
        return response()->json($service->create($data['username'], $data['password'], $data['role']), 201);
    }
}

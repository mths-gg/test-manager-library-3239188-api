<?php

return [
    'accepted' => 'El campo :attribute debe ser aceptado.',
    'array' => 'El campo :attribute debe ser una lista válida.',
    'date_format' => 'El campo :attribute debe tener el formato :format.',
    'file' => 'El campo :attribute debe ser un archivo.',
    'in' => 'El valor seleccionado para :attribute no es válido.',
    'integer' => 'El campo :attribute debe ser un número entero.',
    'max' => [
        'array' => 'El campo :attribute no debe tener más de :max elementos.',
        'file' => 'El archivo :attribute no debe superar :max kilobytes.',
        'numeric' => 'El campo :attribute no debe ser mayor que :max.',
        'string' => 'El campo :attribute no debe tener más de :max caracteres.',
    ],
    'min' => [
        'array' => 'El campo :attribute debe tener al menos :min elementos.',
        'file' => 'El archivo :attribute debe tener al menos :min kilobytes.',
        'numeric' => 'El campo :attribute debe ser como mínimo :min.',
        'string' => 'El campo :attribute debe tener al menos :min caracteres.',
    ],
    'mimes' => 'El campo :attribute debe ser un archivo de tipo: :values.',
    'regex' => 'El formato del campo :attribute no es válido.',
    'required' => 'El campo :attribute es obligatorio.',
    'size' => [
        'numeric' => 'El campo :attribute debe ser :size.',
        'file' => 'El archivo :attribute debe tener :size kilobytes.',
        'string' => 'El campo :attribute debe tener :size caracteres.',
        'array' => 'El campo :attribute debe contener :size elementos.',
    ],
    'string' => 'El campo :attribute debe ser texto.',
    'uuid' => 'El campo :attribute debe ser un UUID válido.',
    'attributes' => [
        'username' => 'usuario', 'password' => 'contraseña', 'role' => 'rol', 'title' => 'título', 'author' => 'autor',
        'isbn' => 'ISBN', 'category_id' => 'categoría', 'total_copies' => 'total de ejemplares',
        'full_name' => 'nombre completo', 'document_number' => 'documento', 'member_id' => 'socio',
        'items' => 'líneas de préstamo', 'file' => 'portada', 'from' => 'fecha inicial', 'to' => 'fecha final',
        'page' => 'página', 'size' => 'tamaño de página',
    ],
];

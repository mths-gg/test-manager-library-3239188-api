# API — Manager Library

Backend REST en Laravel 13 y PHP 8.3+, con PostgreSQL 16. Implementa el contrato del reto bajo `/api/v1`; `GET /health` responde fuera de ese prefijo.

## Capas

- `app/Domain`: entidades, valores e invariantes sin dependencias del framework.
- `app/Application`: puertos y casos de uso.
- `app/Infrastructure`: PostgreSQL, hash Argon2id, JWT HS256, portadas y reloj UTC.
- `app/Http`: controladores, autorización por rol, CORS y errores uniformes.
- `database/migrations`: las seis tablas del esquema `library` y cinco categorías fijas.

Los préstamos bloquean el socio para aplicar el límite de tres incluso si llegan solicitudes simultáneas. La disponibilidad del libro se actualiza condicionalmente por `xmin` dentro de la misma transacción que crea la cabecera y sus líneas. Al devolver una línea, su inventario aumenta una sola vez.

## Ejecución

La forma integrada recomendada está en [`../infra/README.md`](../infra/README.md). Dentro del contenedor:

```bash
php artisan migrate --force
php artisan library:bootstrap-admin
php artisan test
```

Sin Docker, se requieren PHP 8.3+, Composer, extensiones `pdo_pgsql` y `mbstring`, y PostgreSQL 16. Copia `.env.example` a `.env`, configura conexión, `ADMIN_USERNAME`, clave inicial (12+ caracteres) y `JWT_SECRET` (32+ bytes aleatorios). Luego ejecuta `composer install`, `php artisan migrate` y `php artisan library:bootstrap-admin`.

## Contrato

Las rutas y los cuerpos de petición/respuesta se detallan en el [contrato oficial](https://github.com/code-sena/test-manager-library-3239188-docs/blob/main/spec-python/api-contract.md). Los errores JSON usan `{code, message, details}` y los mensajes visibles están en español. Nunca se devuelve ni se registra la contraseña.

El reloj de demostración (`X-Demo-Now`) solo se admite con `APP_ENV=local` o `testing` y `DEMO_CLOCK_ENABLED=true`. Está descrito para la carga de tres préstamos vencidos del sembrador; no modifica el contrato JSON.

## Verificación del espacio de trabajo

Se añadieron pruebas unitarias de dominio y casos de uso, una comprobación de dirección de dependencias y pruebas de límites HTTP (salud, autorización y forma de error). En este entorno no están instalados PHP, Composer ni Docker, así que aquí no fue posible ejecutar PHPUnit, migraciones, la API o Compose. Las instrucciones de verificación quedan listas para el entorno local del aprendiz.
